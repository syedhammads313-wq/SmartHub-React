# SmartHub AI — Landing Page

A premium, futuristic landing page concept for **SmartHub AI**, an all-in-one AI-powered productivity platform (AI chat, image generation, PDF tools, resume builder, learning platform, job marketplace, and more).

## Features of this page
- Dark/light mode toggle
- Glassmorphism cards
- Animated "hub orbit" hero section
- Fully responsive (mobile, tablet, desktop)
- Pricing, testimonials, FAQ, and footer sections
- No build step — pure HTML/CSS/JS

## Run locally
Just open `index.html` in your browser, or serve it with any static server:

```bash
npx serve .
```

## Deploy for free
- **GitHub Pages**: Settings → Pages → Deploy from branch → `main` / root
- **Netlify**: drag-and-drop this folder at netlify.com/drop
- **Vercel**: `vercel deploy`

## Tech
Plain HTML, CSS (custom properties for theming), and vanilla JS. No frameworks, no dependencies.

## Roadmap (not yet built)
This is currently the landing page only. Planned next: Next.js app shell, Firebase Authentication, Firestore database, Stripe billing, and the individual tool pages (AI Chat, Image Generator, PDF Tools, etc.)

## License
© 2026 SmartHub AI. All rights reserved.
