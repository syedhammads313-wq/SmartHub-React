import React, { useState, useEffect, useRef, useMemo } from "react";
import {
  MessageSquare, Image as ImageIcon, FileText, Mail, FilePlus2, RefreshCw,
  GraduationCap, Briefcase, Building2, DollarSign, Calculator as CalcIcon,
  CloudSun, Newspaper, ListChecks, Cloud, BookOpen, LayoutDashboard,
  Sparkles, Moon, SunMedium, Menu, X, ArrowRight, Check, Send, Plus,
  Trash2, ChevronRight, Star, Github, Twitter, Linkedin
} from "lucide-react";

/* ----------------------------------------------------------------------
   TOKENS
   bg      #0B0E1A (dark) / #F6F7FB (light)
   panel   rgba(255,255,255,.05) border rgba(255,255,255,.09)  (dark)
   violet  #7C5CFF   teal #33E7C0   coral #FF6F91   amber #FFB454
   display: Sora   body: Inter   mono: JetBrains Mono
-------------------------------------------------------------------------*/

const TOOLS = [
  { id: "chat", name: "AI Chat Assistant", icon: MessageSquare, accent: "violet", group: "Create", desc: "Conversational AI for writing, research, code and brainstorming." },
  { id: "image", name: "AI Image Generator", icon: ImageIcon, accent: "coral", group: "Create", desc: "Turn prompts into production-ready visuals in seconds." },
  { id: "resume", name: "AI Resume Builder", icon: FileText, accent: "teal", group: "Create", desc: "ATS-optimised resumes tailored to any job description." },
  { id: "writer", name: "Email & Content Writer", icon: Mail, accent: "amber", group: "Create", desc: "Drafts, replies and long-form content in your voice." },
  { id: "pdf", name: "PDF Tools", icon: FilePlus2, accent: "violet", group: "Manage", desc: "Merge, split, compress and convert PDFs instantly." },
  { id: "convert", name: "File Converter", icon: RefreshCw, accent: "teal", group: "Manage", desc: "PDF, Word, Excel, JPG and PNG — convert either way." },
  { id: "storage", name: "Cloud File Storage", icon: Cloud, accent: "coral", group: "Manage", desc: "Encrypted storage that syncs across every device." },
  { id: "notes", name: "Notes & To‑Do", icon: ListChecks, accent: "amber", group: "Manage", desc: "Capture tasks and ideas, organised automatically." },
  { id: "learn", name: "Online Learning", icon: GraduationCap, accent: "violet", group: "Grow", desc: "Structured courses with AI-guided learning paths." },
  { id: "jobs", name: "Job & Freelance Marketplace", icon: Briefcase, accent: "teal", group: "Grow", desc: "Find work, hire talent, or land your next role." },
  { id: "business", name: "Business Tools", icon: Building2, accent: "coral", group: "Grow", desc: "Invoicing, proposals and reporting for small teams." },
  { id: "blog", name: "Blog & Articles", icon: BookOpen, accent: "amber", group: "Grow", desc: "Insights on AI, productivity and remote work." },
  { id: "currency", name: "Currency Converter", icon: DollarSign, accent: "violet", group: "Everyday", desc: "Live rates across 150+ currencies." },
  { id: "calc", name: "Calculator Hub", icon: CalcIcon, accent: "teal", group: "Everyday", desc: "Scientific, finance, health and unit calculators." },
  { id: "weather", name: "Weather Forecast", icon: CloudSun, accent: "coral", group: "Everyday", desc: "Hyperlocal forecasts, hour by hour." },
  { id: "news", name: "Live News", icon: Newspaper, accent: "amber", group: "Everyday", desc: "Curated headlines from sources you trust." },
];

const GROUPS = ["Create", "Manage", "Grow", "Everyday"];

const ACCENTS = {
  violet: { text: "text-violet-300", bg: "bg-violet-500/15", ring: "ring-violet-400/30", dot: "#7C5CFF", grad: "from-violet-500/25" },
  teal: { text: "text-teal-300", bg: "bg-teal-500/15", ring: "ring-teal-400/30", dot: "#33E7C0", grad: "from-teal-400/25" },
  coral: { text: "text-rose-300", bg: "bg-rose-500/15", ring: "ring-rose-400/30", dot: "#FF6F91", grad: "from-rose-400/25" },
  amber: { text: "text-amber-300", bg: "bg-amber-500/15", ring: "ring-amber-400/30", dot: "#FFB454", grad: "from-amber-400/25" },
};

function useDark() {
  const [dark, setDark] = useState(true);
  return [dark, setDark];
}

/* ---------------------------- Command Bar -------------------------------- */
function CommandBar({ dark }) {
  const prompts = useMemo(() => [
    "Write a cover letter for a product design role…",
    "Generate a logo for a coffee subscription brand…",
    "Summarise this 40-page contract into 5 bullets…",
    "Convert Q3-report.docx to PDF and compress it…",
    "Plan a 6-week learning path for SQL…",
  ], []);
  const [i, setI] = useState(0);
  const [sub, setSub] = useState(0);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    const current = prompts[i];
    const speed = deleting ? 22 : 34;
    const t = setTimeout(() => {
      if (!deleting && sub < current.length) setSub(sub + 1);
      else if (!deleting && sub === current.length) setTimeout(() => setDeleting(true), 1200);
      else if (deleting && sub > 0) setSub(sub - 1);
      else { setDeleting(false); setI((i + 1) % prompts.length); }
    }, speed);
    return () => clearTimeout(t);
  }, [sub, deleting, i, prompts]);

  return (
    <div className={`relative w-full max-w-xl rounded-2xl p-[1px] bg-gradient-to-r from-violet-500/40 via-teal-400/40 to-rose-400/40`}>
      <div className={`flex items-center gap-3 rounded-2xl px-5 py-4 backdrop-blur-xl ${dark ? "bg-[#0E1120]/90" : "bg-white/90"}`}>
        <Sparkles size={18} className="text-violet-400 shrink-0" />
        <span className={`text-sm sm:text-[15px] font-mono truncate ${dark ? "text-slate-300" : "text-slate-600"}`}>
          {prompts[i].slice(0, sub)}<span className="animate-pulse">|</span>
        </span>
      </div>
    </div>
  );
}

/* ---------------------------- Hero Orbit -------------------------------- */
function OrbitHero({ dark }) {
  const ring = [
    { icon: MessageSquare, accent: "violet", r: 132, dur: 22 },
    { icon: ImageIcon, accent: "coral", r: 132, dur: 26 },
    { icon: FileText, accent: "teal", r: 132, dur: 30 },
    { icon: Briefcase, accent: "amber", r: 132, dur: 24 },
    { icon: RefreshCw, accent: "violet", r: 190, dur: 34 },
    { icon: GraduationCap, accent: "teal", r: 190, dur: 38 },
    { icon: CloudSun, accent: "coral", r: 190, dur: 42 },
  ];
  return (
    <div className="relative mx-auto h-[300px] w-[300px] sm:h-[380px] sm:w-[380px] shrink-0">
      <div className={`absolute inset-0 rounded-full blur-3xl ${dark ? "bg-violet-600/20" : "bg-violet-300/40"}`} />
      {[132, 190].map((r) => (
        <div key={r} className={`absolute rounded-full border ${dark ? "border-white/10" : "border-slate-900/10"}`}
          style={{ width: r * 2, height: r * 2, top: "50%", left: "50%", transform: "translate(-50%,-50%)" }} />
      ))}
      <div className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 h-20 w-20 sm:h-24 sm:w-24 rounded-3xl grid place-items-center
        bg-gradient-to-br from-violet-500 to-teal-400 shadow-[0_0_60px_-10px_rgba(124,92,255,0.7)]`}>
        <Sparkles className="text-white" size={30} />
      </div>
      {ring.map((n, idx) => {
        const a = ACCENTS[n.accent];
        return (
          <div key={idx} className="absolute inset-0" style={{ animation: `spin ${n.dur}s linear infinite` }}>
            <div className="absolute rounded-2xl p-2.5 backdrop-blur-md ring-1"
              style={{
                top: `calc(50% - ${n.r}px)`, left: "50%", transform: "translateX(-50%)",
                background: dark ? "rgba(255,255,255,0.06)" : "rgba(255,255,255,0.8)",
              }}>
              <div style={{ animation: `spin-rev ${n.dur}s linear infinite` }}>
                <n.icon size={18} className={a.text} />
              </div>
            </div>
          </div>
        );
      })}
      <style>{`
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        @keyframes spin-rev { from { transform: rotate(0deg); } to { transform: rotate(-360deg); } }
      `}</style>
    </div>
  );
}

/* ---------------------------- Shared Panel -------------------------------- */
function Panel({ dark, className = "", children }) {
  return (
    <div className={`rounded-3xl ring-1 backdrop-blur-xl ${dark ? "bg-white/[0.04] ring-white/10" : "bg-white/70 ring-slate-900/10"} ${className}`}>
      {children}
    </div>
  );
}

/* ---------------------------- Demo: Chat -------------------------------- */
function ChatDemo({ dark }) {
  const [msgs, setMsgs] = useState([
    { role: "assistant", text: "Hi, I'm your SmartHub assistant. Ask me to draft, plan, or explain anything." },
  ]);
  const [val, setVal] = useState("");
  const endRef = useRef(null);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs]);

  const send = () => {
    if (!val.trim()) return;
    const userMsg = val.trim();
    setMsgs((m) => [...m, { role: "user", text: userMsg }]);
    setVal("");
    setTimeout(() => {
      setMsgs((m) => [...m, {
        role: "assistant",
        text: "This is a front-end preview, so responses are simulated — connect an API key in the real build and this becomes a live model call.",
      }]);
    }, 500);
  };

  return (
    <Panel dark={dark} className="flex flex-col h-[420px] overflow-hidden">
      <div className="flex-1 overflow-y-auto p-5 space-y-3">
        {msgs.map((m, i) => (
          <div key={i} className={`max-w-[85%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed ${
            m.role === "user"
              ? `ml-auto ${dark ? "bg-violet-500/25 text-violet-50" : "bg-violet-600 text-white"}`
              : `${dark ? "bg-white/[0.06] text-slate-200" : "bg-slate-100 text-slate-700"}`
          }`}>
            {m.text}
          </div>
        ))}
        <div ref={endRef} />
      </div>
      <div className={`flex items-center gap-2 p-3 border-t ${dark ? "border-white/10" : "border-slate-900/10"}`}>
        <input
          value={val}
          onChange={(e) => setVal(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && send()}
          placeholder="Ask SmartHub anything…"
          className={`flex-1 rounded-xl px-4 py-2.5 text-sm outline-none ${dark ? "bg-white/[0.06] text-slate-100 placeholder:text-slate-500" : "bg-slate-100 text-slate-800 placeholder:text-slate-400"}`}
        />
        <button onClick={send} className="rounded-xl bg-gradient-to-br from-violet-500 to-teal-400 p-2.5 text-white shrink-0">
          <Send size={16} />
        </button>
      </div>
    </Panel>
  );
}

/* ---------------------------- Demo: Calculator -------------------------------- */
function CalculatorDemo({ dark }) {
  const [expr, setExpr] = useState("");
  const [result, setResult] = useState("0");
  const press = (k) => setExpr((e) => e + k);
  const clear = () => { setExpr(""); setResult("0"); };
  const back = () => setExpr((e) => e.slice(0, -1));
  const evaluate = () => {
    try {
      if (!/^[0-9+\-*/.() %]*$/.test(expr)) throw new Error("bad");
      // eslint-disable-next-line no-new-func
      const val = Function(`"use strict"; return (${expr.replace(/%/g, "/100")})`)();
      setResult(Number.isFinite(val) ? String(val) : "Error");
    } catch { setResult("Error"); }
  };
  const keys = ["7", "8", "9", "/", "4", "5", "6", "*", "1", "2", "3", "-", "0", ".", "%", "+"];
  return (
    <Panel dark={dark} className="p-5">
      <div className={`rounded-2xl p-4 mb-4 ${dark ? "bg-black/30" : "bg-slate-100"}`}>
        <div className={`text-right font-mono text-sm min-h-[18px] ${dark ? "text-slate-400" : "text-slate-500"}`}>{expr || " "}</div>
        <div className={`text-right font-mono text-3xl font-semibold ${dark ? "text-white" : "text-slate-900"}`}>{result}</div>
      </div>
      <div className="grid grid-cols-4 gap-2">
        {keys.map((k) => (
          <button key={k} onClick={() => press(k)}
            className={`rounded-xl py-3 text-sm font-mono font-medium transition ${dark ? "bg-white/[0.06] hover:bg-white/[0.12] text-slate-100" : "bg-slate-100 hover:bg-slate-200 text-slate-800"}`}>
            {k}
          </button>
        ))}
      </div>
      <div className="grid grid-cols-3 gap-2 mt-2">
        <button onClick={clear} className="rounded-xl py-3 text-sm font-medium bg-rose-500/20 text-rose-300 hover:bg-rose-500/30">AC</button>
        <button onClick={back} className={`rounded-xl py-3 text-sm font-medium ${dark ? "bg-white/[0.06] text-slate-100" : "bg-slate-100 text-slate-800"}`}>⌫</button>
        <button onClick={evaluate} className="rounded-xl py-3 text-sm font-semibold bg-gradient-to-br from-violet-500 to-teal-400 text-white">=</button>
      </div>
    </Panel>
  );
}

/* ---------------------------- Demo: Currency -------------------------------- */
function CurrencyDemo({ dark }) {
  const rates = { USD: 1, EUR: 0.92, GBP: 0.78, INR: 83.4, JPY: 155.2, AUD: 1.5, CAD: 1.36 };
  const [amount, setAmount] = useState(100);
  const [from, setFrom] = useState("USD");
  const [to, setTo] = useState("EUR");
  const converted = (amount / rates[from]) * rates[to];
  return (
    <Panel dark={dark} className="p-6 space-y-4">
      <p className={`text-xs ${dark ? "text-slate-400" : "text-slate-500"}`}>Demo rates — the production build calls a live FX API.</p>
      <div>
        <label className={`text-xs uppercase tracking-wide ${dark ? "text-slate-400" : "text-slate-500"}`}>Amount</label>
        <input type="number" value={amount} onChange={(e) => setAmount(Number(e.target.value) || 0)}
          className={`w-full mt-1 rounded-xl px-4 py-2.5 text-sm outline-none ${dark ? "bg-white/[0.06] text-white" : "bg-slate-100 text-slate-800"}`} />
      </div>
      <div className="grid grid-cols-2 gap-3">
        {[["From", from, setFrom], ["To", to, setTo]].map(([label, val, setter]) => (
          <div key={label}>
            <label className={`text-xs uppercase tracking-wide ${dark ? "text-slate-400" : "text-slate-500"}`}>{label}</label>
            <select value={val} onChange={(e) => setter(e.target.value)}
              className={`w-full mt-1 rounded-xl px-3 py-2.5 text-sm outline-none ${dark ? "bg-white/[0.06] text-white" : "bg-slate-100 text-slate-800"}`}>
              {Object.keys(rates).map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
        ))}
      </div>
      <div className={`rounded-2xl p-5 text-center ${dark ? "bg-black/30" : "bg-slate-100"}`}>
        <div className={`text-xs uppercase tracking-wide ${dark ? "text-slate-400" : "text-slate-500"}`}>Converted</div>
        <div className="font-mono text-3xl font-semibold mt-1 bg-gradient-to-r from-violet-400 to-teal-300 bg-clip-text text-transparent">
          {converted.toLocaleString(undefined, { maximumFractionDigits: 2 })} {to}
        </div>
      </div>
    </Panel>
  );
}

/* ---------------------------- Demo: Notes -------------------------------- */
function NotesDemo({ dark }) {
  const [items, setItems] = useState([
    { id: 1, text: "Draft Q3 investor update", done: false },
    { id: 2, text: "Export resume as PDF", done: true },
  ]);
  const [val, setVal] = useState("");
  const add = () => {
    if (!val.trim()) return;
    setItems((i) => [...i, { id: Date.now(), text: val.trim(), done: false }]);
    setVal("");
  };
  const toggle = (id) => setItems((i) => i.map((it) => (it.id === id ? { ...it, done: !it.done } : it)));
  const remove = (id) => setItems((i) => i.filter((it) => it.id !== id));
  return (
    <Panel dark={dark} className="p-6">
      <div className="flex gap-2 mb-4">
        <input value={val} onChange={(e) => setVal(e.target.value)} onKeyDown={(e) => e.key === "Enter" && add()}
          placeholder="Add a task…"
          className={`flex-1 rounded-xl px-4 py-2.5 text-sm outline-none ${dark ? "bg-white/[0.06] text-white placeholder:text-slate-500" : "bg-slate-100 text-slate-800 placeholder:text-slate-400"}`} />
        <button onClick={add} className="rounded-xl bg-gradient-to-br from-violet-500 to-teal-400 p-2.5 text-white"><Plus size={16} /></button>
      </div>
      <div className="space-y-2 max-h-[240px] overflow-y-auto">
        {items.map((it) => (
          <div key={it.id} className={`flex items-center gap-3 rounded-xl px-3 py-2.5 ${dark ? "bg-white/[0.04]" : "bg-slate-50"}`}>
            <button onClick={() => toggle(it.id)}
              className={`h-5 w-5 shrink-0 rounded-md ring-1 grid place-items-center ${it.done ? "bg-teal-400 ring-teal-400" : dark ? "ring-white/20" : "ring-slate-300"}`}>
              {it.done && <Check size={13} className="text-slate-900" />}
            </button>
            <span className={`flex-1 text-sm ${it.done ? "line-through opacity-50" : ""} ${dark ? "text-slate-100" : "text-slate-700"}`}>{it.text}</span>
            <button onClick={() => remove(it.id)} className="text-slate-400 hover:text-rose-400"><Trash2 size={15} /></button>
          </div>
        ))}
        {items.length === 0 && <p className={`text-sm text-center py-6 ${dark ? "text-slate-500" : "text-slate-400"}`}>Nothing here yet — add your first task.</p>}
      </div>
    </Panel>
  );
}

const DEMOS = {
  chat: { label: "AI Chat", icon: MessageSquare, Component: ChatDemo },
  calc: { label: "Calculator", icon: CalcIcon, Component: CalculatorDemo },
  currency: { label: "Currency", icon: DollarSign, Component: CurrencyDemo },
  notes: { label: "Notes & To‑Do", icon: ListChecks, Component: NotesDemo },
};

/* ---------------------------- Page -------------------------------- */
export default function SmartHubAI() {
  const [dark, setDark] = useDark();
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeDemo, setActiveDemo] = useState("chat");
  const [activeGroup, setActiveGroup] = useState("Create");

  const bg = dark ? "bg-[#0B0E1A] text-slate-100" : "bg-[#F6F7FB] text-slate-900";
  const ActiveDemo = DEMOS[activeDemo].Component;

  const plans = [
    { name: "Free", price: "$0", tag: "Get started", features: ["AI Chat (limited)", "3 image generations/day", "Basic PDF tools", "1GB cloud storage"], featured: false },
    { name: "Pro", price: "$19", tag: "For individuals", features: ["Unlimited AI Chat", "Unlimited image generation", "All PDF & file tools", "50GB cloud storage", "Resume & content writer"], featured: true },
    { name: "Business", price: "$49", tag: "For teams", features: ["Everything in Pro", "Team workspaces", "Job & freelance postings", "Priority support", "Admin dashboard & analytics"], featured: false },
  ];

  const testimonials = [
    { name: "Amara Chen", role: "Freelance Designer", quote: "I replaced six subscriptions with one SmartHub plan. The resume builder alone paid for the year." },
    { name: "Diego Ruiz", role: "Startup Founder", quote: "Our whole team moved off scattered tools. Everything from invoices to job posts lives here now." },
    { name: "Priya Nair", role: "Grad Student", quote: "The learning paths and PDF tools saved me hours every week during thesis season." },
  ];

  return (
    <div className={`min-h-screen w-full transition-colors duration-300 ${bg}`}>
      {/* NAV */}
      <header className={`sticky top-0 z-50 backdrop-blur-xl ${dark ? "bg-[#0B0E1A]/70" : "bg-[#F6F7FB]/70"} border-b ${dark ? "border-white/5" : "border-slate-900/5"}`}>
        <div className="max-w-7xl mx-auto px-5 sm:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2 font-semibold tracking-tight" style={{ fontFamily: "'Sora', sans-serif" }}>
            <div className="h-8 w-8 rounded-xl bg-gradient-to-br from-violet-500 to-teal-400 grid place-items-center">
              <Sparkles size={16} className="text-white" />
            </div>
            SmartHub <span className="text-violet-400">AI</span>
          </div>
          <nav className="hidden md:flex items-center gap-8 text-sm">
            {["Tools", "Pricing", "Learning", "About"].map((l) => (
              <a key={l} href={`#${l.toLowerCase()}`} className={`${dark ? "text-slate-300 hover:text-white" : "text-slate-600 hover:text-slate-900"} transition`}>{l}</a>
            ))}
          </nav>
          <div className="flex items-center gap-3">
            <button onClick={() => setDark(!dark)} className={`h-9 w-9 rounded-full grid place-items-center ring-1 ${dark ? "ring-white/10 text-amber-300" : "ring-slate-900/10 text-slate-600"}`}>
              {dark ? <SunMedium size={16} /> : <Moon size={16} />}
            </button>
            <button className="hidden sm:block rounded-full px-5 py-2 text-sm font-medium bg-gradient-to-br from-violet-500 to-teal-400 text-white">
              Sign in
            </button>
            <button className="md:hidden" onClick={() => setMenuOpen(!menuOpen)}>
              {menuOpen ? <X size={22} /> : <Menu size={22} />}
            </button>
          </div>
        </div>
        {menuOpen && (
          <div className={`md:hidden px-5 pb-4 flex flex-col gap-3 text-sm ${dark ? "bg-[#0B0E1A]" : "bg-[#F6F7FB]"}`}>
            {["Tools", "Pricing", "Learning", "About"].map((l) => (
              <a key={l} href={`#${l.toLowerCase()}`} onClick={() => setMenuOpen(false)}>{l}</a>
            ))}
          </div>
        )}
      </header>

      {/* HERO */}
      <section className="max-w-7xl mx-auto px-5 sm:px-8 pt-16 sm:pt-24 pb-16 grid lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-6 order-2 lg:order-1">
          <div className={`inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-xs ring-1 ${dark ? "ring-white/10 text-slate-300" : "ring-slate-900/10 text-slate-600"}`}>
            <span className="h-1.5 w-1.5 rounded-full bg-teal-400" /> 16 tools. One workspace. Zero context-switching.
          </div>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-semibold leading-[1.05] tracking-tight" style={{ fontFamily: "'Sora', sans-serif" }}>
            The AI hub that replaces
            <span className="block bg-gradient-to-r from-violet-400 via-teal-300 to-rose-300 bg-clip-text text-transparent">your other twelve tabs.</span>
          </h1>
          <p className={`text-base sm:text-lg max-w-lg ${dark ? "text-slate-400" : "text-slate-600"}`}>
            Chat, generate images, build your resume, convert files, learn new skills, and run your freelance business — all in one premium workspace built around a single AI core.
          </p>
          <CommandBar dark={dark} />
          <div className="flex flex-wrap gap-3 pt-2">
            <button className="rounded-full px-6 py-3 text-sm font-medium bg-gradient-to-br from-violet-500 to-teal-400 text-white flex items-center gap-2">
              Start for free <ArrowRight size={15} />
            </button>
            <button className={`rounded-full px-6 py-3 text-sm font-medium ring-1 ${dark ? "ring-white/15 text-slate-200" : "ring-slate-900/10 text-slate-700"}`}>
              See it in action
            </button>
          </div>
        </div>
        <div className="order-1 lg:order-2 flex justify-center">
          <OrbitHero dark={dark} />
        </div>
      </section>

      {/* TOOLS */}
      <section id="tools" className="max-w-7xl mx-auto px-5 sm:px-8 py-16">
        <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4 mb-8">
          <div>
            <p className="text-sm text-violet-400 font-medium mb-2">The workspace</p>
            <h2 className="text-3xl sm:text-4xl font-semibold tracking-tight" style={{ fontFamily: "'Sora', sans-serif" }}>Sixteen tools, four jobs to be done.</h2>
          </div>
          <div className={`flex gap-1 rounded-full p-1 ring-1 self-start ${dark ? "ring-white/10" : "ring-slate-900/10"}`}>
            {GROUPS.map((g) => (
              <button key={g} onClick={() => setActiveGroup(g)}
                className={`px-4 py-1.5 rounded-full text-xs font-medium transition ${activeGroup === g ? "bg-gradient-to-br from-violet-500 to-teal-400 text-white" : dark ? "text-slate-400" : "text-slate-500"}`}>
                {g}
              </button>
            ))}
          </div>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {TOOLS.filter((t) => t.group === activeGroup).map((t) => {
            const a = ACCENTS[t.accent];
            return (
              <Panel key={t.id} dark={dark} className="p-5 hover:-translate-y-1 transition-transform duration-300">
                <div className={`h-11 w-11 rounded-2xl grid place-items-center mb-4 ${a.bg}`}>
                  <t.icon size={20} className={a.text} />
                </div>
                <h3 className="font-medium mb-1.5">{t.name}</h3>
                <p className={`text-sm leading-relaxed ${dark ? "text-slate-400" : "text-slate-500"}`}>{t.desc}</p>
              </Panel>
            );
          })}
        </div>
      </section>

      {/* LIVE DEMO */}
      <section className="max-w-7xl mx-auto px-5 sm:px-8 py-16">
        <p className="text-sm text-teal-400 font-medium mb-2 text-center">Try it now</p>
        <h2 className="text-3xl sm:text-4xl font-semibold tracking-tight text-center mb-8" style={{ fontFamily: "'Sora', sans-serif" }}>
          A few tools, live in your browser.
        </h2>
        <div className="flex justify-center gap-2 mb-8 flex-wrap">
          {Object.entries(DEMOS).map(([key, d]) => (
            <button key={key} onClick={() => setActiveDemo(key)}
              className={`flex items-center gap-2 rounded-full px-4 py-2 text-sm font-medium ring-1 transition ${
                activeDemo === key
                  ? "bg-gradient-to-br from-violet-500 to-teal-400 text-white ring-transparent"
                  : dark ? "ring-white/10 text-slate-300" : "ring-slate-900/10 text-slate-600"
              }`}>
              <d.icon size={15} /> {d.label}
            </button>
          ))}
        </div>
        <div className="max-w-md mx-auto">
          <ActiveDemo dark={dark} />
        </div>
      </section>

      {/* PRICING */}
      <section id="pricing" className="max-w-7xl mx-auto px-5 sm:px-8 py-16">
        <p className="text-sm text-rose-400 font-medium mb-2 text-center">Pricing</p>
        <h2 className="text-3xl sm:text-4xl font-semibold tracking-tight text-center mb-10" style={{ fontFamily: "'Sora', sans-serif" }}>
          Simple plans that scale with you.
        </h2>
        <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {plans.map((p) => (
            <Panel key={p.name} dark={dark} className={`p-7 flex flex-col ${p.featured ? "ring-2 ring-violet-400/60 scale-[1.03]" : ""}`}>
              {p.featured && <span className="self-start mb-3 rounded-full bg-gradient-to-br from-violet-500 to-teal-400 text-white text-xs px-3 py-1">Most popular</span>}
              <h3 className="text-lg font-medium">{p.name}</h3>
              <p className={`text-xs mb-4 ${dark ? "text-slate-400" : "text-slate-500"}`}>{p.tag}</p>
              <div className="text-4xl font-semibold mb-6" style={{ fontFamily: "'Sora', sans-serif" }}>{p.price}<span className={`text-sm font-normal ${dark ? "text-slate-400" : "text-slate-500"}`}>/mo</span></div>
              <ul className="space-y-2.5 mb-8 flex-1">
                {p.features.map((f) => (
                  <li key={f} className="flex items-start gap-2 text-sm">
                    <Check size={15} className="text-teal-400 mt-0.5 shrink-0" />
                    <span className={dark ? "text-slate-300" : "text-slate-600"}>{f}</span>
                  </li>
                ))}
              </ul>
              <button className={`rounded-full py-2.5 text-sm font-medium ${p.featured ? "bg-gradient-to-br from-violet-500 to-teal-400 text-white" : dark ? "ring-1 ring-white/15 text-slate-200" : "ring-1 ring-slate-900/10 text-slate-700"}`}>
                Choose {p.name}
              </button>
            </Panel>
          ))}
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="max-w-7xl mx-auto px-5 sm:px-8 py-16">
        <h2 className="text-3xl sm:text-4xl font-semibold tracking-tight text-center mb-10" style={{ fontFamily: "'Sora', sans-serif" }}>
          Loved by people juggling too many tools.
        </h2>
        <div className="grid md:grid-cols-3 gap-6">
          {testimonials.map((t) => (
            <Panel key={t.name} dark={dark} className="p-6">
              <div className="flex gap-1 mb-3">{Array.from({ length: 5 }).map((_, i) => <Star key={i} size={14} className="fill-amber-400 text-amber-400" />)}</div>
              <p className={`text-sm leading-relaxed mb-4 ${dark ? "text-slate-300" : "text-slate-600"}`}>"{t.quote}"</p>
              <div className="text-sm font-medium">{t.name}</div>
              <div className={`text-xs ${dark ? "text-slate-500" : "text-slate-400"}`}>{t.role}</div>
            </Panel>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="max-w-7xl mx-auto px-5 sm:px-8 py-16">
        <Panel dark={dark} className="p-10 sm:p-14 text-center bg-gradient-to-br from-violet-500/10 via-transparent to-teal-400/10">
          <h2 className="text-3xl sm:text-4xl font-semibold tracking-tight mb-3" style={{ fontFamily: "'Sora', sans-serif" }}>Ready to close eleven tabs?</h2>
          <p className={`mb-6 ${dark ? "text-slate-400" : "text-slate-600"}`}>Start free. Upgrade whenever the work demands it.</p>
          <button className="rounded-full px-7 py-3 text-sm font-medium bg-gradient-to-br from-violet-500 to-teal-400 text-white inline-flex items-center gap-2">
            Create your account <ChevronRight size={15} />
          </button>
        </Panel>
      </section>

      {/* FOOTER */}
      <footer className={`border-t ${dark ? "border-white/5" : "border-slate-900/5"}`}>
        <div className="max-w-7xl mx-auto px-5 sm:px-8 py-12 grid sm:grid-cols-2 lg:grid-cols-5 gap-8">
          <div className="lg:col-span-2">
            <div className="flex items-center gap-2 font-semibold mb-3" style={{ fontFamily: "'Sora', sans-serif" }}>
              <div className="h-7 w-7 rounded-lg bg-gradient-to-br from-violet-500 to-teal-400 grid place-items-center">
                <Sparkles size={14} className="text-white" />
              </div>
              SmartHub AI
            </div>
            <p className={`text-sm max-w-xs ${dark ? "text-slate-400" : "text-slate-500"}`}>One AI-powered workspace for creating, managing, learning and earning.</p>
            <div className="flex gap-3 mt-4">
              {[Github, Twitter, Linkedin].map((Icon, i) => (
                <div key={i} className={`h-8 w-8 rounded-full grid place-items-center ring-1 ${dark ? "ring-white/10 text-slate-300" : "ring-slate-900/10 text-slate-600"}`}><Icon size={14} /></div>
              ))}
            </div>
          </div>
          {[
            { title: "Product", links: ["Tools", "Pricing", "Learning", "Marketplace"] },
            { title: "Company", links: ["About us", "Blog", "Careers", "Contact"] },
            { title: "Resources", links: ["FAQ", "Help centre", "API status", "Community"] },
            { title: "Legal", links: ["Privacy policy", "Terms & conditions", "Security"] },
          ].map((col) => (
            <div key={col.title}>
              <div className="text-sm font-medium mb-3">{col.title}</div>
              <ul className="space-y-2">
                {col.links.map((l) => (
                  <li key={l}><a href="#" className={`text-sm ${dark ? "text-slate-400 hover:text-white" : "text-slate-500 hover:text-slate-900"}`}>{l}</a></li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className={`text-center text-xs pb-8 ${dark ? "text-slate-500" : "text-slate-400"}`}>© 2026 SmartHub AI. All rights reserved.</div>
      </footer>

    </div>
  );
}
