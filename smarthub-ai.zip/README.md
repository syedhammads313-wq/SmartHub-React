# SmartHub AI

A premium, animated landing page + interactive demo hub for "SmartHub AI" — an all-in-one AI platform concept (chat, image generation, resume builder, PDF/file tools, calculator, currency converter, notes, and more).

Built with **React + Vite + Tailwind CSS**. This is the front-end/design layer — it does not include a real backend (auth, database, payments). See "Next steps" below for turning this into a full production app.

## Run it locally

```bash
npm install
npm run dev
```

Then open the local URL Vite prints (usually `http://localhost:5173`).

## Build for production

```bash
npm run build
npm run preview
```

## Upload to GitHub

If you don't already have a GitHub repo for this:

1. Go to https://github.com/new and create a new repository (don't add a README/license there — this project already has one).
2. In this project folder, run:

```bash
git init
git add .
git commit -m "Initial commit: SmartHub AI landing page"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPO-NAME.git
git push -u origin main
```

Replace `YOUR-USERNAME/YOUR-REPO-NAME` with your actual GitHub repo path.

## Deploy

Once it's on GitHub, you can deploy it for free in a couple of clicks with:
- **Vercel** (https://vercel.com) — import the GitHub repo, framework preset "Vite", deploy.
- **Netlify** (https://netlify.com) — same idea, build command `npm run build`, publish directory `dist`.

## Next steps toward the full 25-feature platform

This project currently ships the landing page and four working demo tools (AI Chat UI, Calculator, Currency Converter, Notes/To-Do) using local state only. To grow this into the complete platform described in the brief, you'd add:

- **Next.js** (instead of Vite) if you want server-side rendering, API routes, and file-based routing for each feature page.
- **Firebase Authentication + Firestore** for real login (Google/Facebook/Email) and data storage.
- **Stripe** for the Free/Pro/Business subscription billing.
- Real APIs behind the AI Chat, Image Generator, PDF tools, File Converter, Weather, and News features.
- A `next-pwa` config (or Vite PWA plugin) for installable/offline support.

Happy to scaffold any of these pieces next — just say which one to build first.
